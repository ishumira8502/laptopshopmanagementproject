package com.laptopshop.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.laptopshop.model.LaptopDetails;

@Repository
public interface LaptopDetailsRepository extends JpaRepository<LaptopDetails, Long>{
		

	}