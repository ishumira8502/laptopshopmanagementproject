package com.laptopshop.model;

 import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name="laptopdetails")
public class LaptopDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Laptop_ModelId")
	private long laptopModelId;
	
	@Column(name="Laptop_BrandName")
	private String laptopBrandName;
	
	@Column(name="Laptop_Specification")
	private String laptopSpecification;
	
	@Column(name="Laptop_Os")
	private String laptopOs;
	
	@Column(name="Laptop_ItemPrice")
	private String laptopItemPrice;
	
	@Column(name="Laptop_WarrantyPeriod")
	private int laptopWarrantyPeriod;

	@OneToOne
	@JoinColumn(name="User_Id")
	@JsonIgnore
	private Users users;

	public LaptopDetails(Users users) {
		super();
		this.users = users;
	}

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}

	public long getLaptopModelId() {
		return laptopModelId;
	}

	public void setLaptopModelId(long laptopModelId) {
		this.laptopModelId = laptopModelId;
	}

	public String getLaptopBrandName() {
		return laptopBrandName;
	}

	public void setLaptopBrandName(String laptopBrandName) {
		this.laptopBrandName = laptopBrandName;
	}

	public String getLaptopSpecification() {
		return laptopSpecification;
	}

	public void setLaptopSpecification(String laptopSpecification) {
		this.laptopSpecification = laptopSpecification;
	}

	public String getLaptopOs() {
		return laptopOs;
	}

	public void setLaptopOs(String laptopOs) {
		this.laptopOs = laptopOs;
	}

	public String getLaptopItemPrice() {
		return laptopItemPrice;
	}

	public void setLaptopItemPrice(String laptopItemPrice) {
		this.laptopItemPrice = laptopItemPrice;
	}

	public int getLaptopWarrantyPeriod() {
		return laptopWarrantyPeriod;
	}

	public void setLaptopWarrantyPeriod(int laptopWarrantyPeriod) {
		this.laptopWarrantyPeriod = laptopWarrantyPeriod;
	}

	public LaptopDetails(long laptopModelId, String laptopBrandName, String laptopSpecification,
			String laptopOs, String laptopItemPrice, int laptopWarrantyPeriod) {
		super();
		this.laptopModelId = laptopModelId;
		this.laptopBrandName = laptopBrandName;
		this.laptopSpecification = laptopSpecification;
		this.laptopOs = laptopOs;
		this.laptopItemPrice = laptopItemPrice;
		this.laptopWarrantyPeriod =laptopWarrantyPeriod;
	}
	
	}
	
