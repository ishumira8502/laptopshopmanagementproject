package com.laptopshop.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name="users")
public class Users {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long userId;
	
	@Column(name="User_Name")
	@NotEmpty
	@Size(min=3,message="name must contain atleast 3 character")
	private String userName ;
    @Column(name="User_EmailId",unique=true)
	@NotEmpty
	@Email(message="Email is not valid")
    public String userEmailId;
    @Column(name="User_Password")
	@NotEmpty
	@Size(min=8 , message="Password length must be 8 and contain uppercase,lowercase ,digits")
	@Pattern(regexp="(?=.*\\d)(?=.[a-z])(?=.*[A-Z]).{8,}")
    public String userPassword;
    @Column(name="User_PhoneNo")
	@NotEmpty
	@Size(min=10 ,max=10, message="PhoneNo must contain 10 digits")
    private String userPhoneNo;
 /*public Users(long userId, @NotEmpty @Size(min = 3, message = "name must contain atleast 3 character")
 String userName,
		@NotEmpty @Email(message = "Email is not valid") String userEmailId,
		@NotEmpty @Size(min = 8, message = "Password length must be 8 and contain uppercase,lowercase ,digits") @Pattern(regexp = "(?=.\\d)(?=.[a-z])(?=.*[A-Z]).{8,}") String userPassword,
		@NotEmpty @Size(min = 10, max = 10, message = "PhoneNo must contain 10 digits") String userPhoneNo) {
	super();
	this.userId = userId;
	this.userName = userName;
	this.userEmailId = userEmailId;
	this.userPassword = userPassword;
	this.userPhoneNo = userPhoneNo;
}*/
 public Users() {}
public long getUserId() {
	return userId;
}
public void setUserId(long userId) {
	this.userId = userId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUserEmailId() {
	return userEmailId;
}
public void setUserEmailId(String userEmailId) {
	this.userEmailId = userEmailId;
}
public String getUserPassword() {
	return userPassword;
}
public void setUserPassword(String userPassword) {
	this.userPassword = userPassword;
}
public String getUserPhoneNo() {
	return userPhoneNo;
}
public void setUserPhoneNo(String userPhoneNo) {
	this.userPhoneNo = userPhoneNo;
}

}

