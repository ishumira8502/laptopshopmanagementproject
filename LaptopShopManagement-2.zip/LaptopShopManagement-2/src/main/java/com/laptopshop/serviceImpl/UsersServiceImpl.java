package com.laptopshop.serviceImpl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.laptopshop.exception.UsersNotFoundException;
import com.laptopshop.model.Users;
import com.laptopshop.repository.UsersRepository;
import com.laptopshop.service.UsersService;


@Service
public class UsersServiceImpl implements UsersService{
	
	@Autowired
private UsersRepository usersRepository;

	public UsersServiceImpl(UsersRepository usersRepository) {
	super();
	this.usersRepository = usersRepository;
}

	@Override
	public Users saveUsers(Users users) {
		System.out.println("admin register service"+users);

		return usersRepository.save(users);
	}

	@Override
	public Users loginUsers(Users users) {
		return this.usersRepository.findByUserEmailIdAndUserPassword(users.userEmailId,users.userPassword).orElseThrow(()->new UsersNotFoundException("Users ", "Id",users.userEmailId+"and password "+users.userPassword ));
	}
	
	@Override
	public Users getUserById(long userId) {
		return this.usersRepository.findById(userId).get();
	}

}