package com.laptopshop.serviceImpl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.laptopshop.exception.CustomerNotFoundException;
import com.laptopshop.model.Customer;
import com.laptopshop.repository.CustomerRepository;
import com.laptopshop.service.CustomerService;

@Service
public  class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;
		
		
		
		public CustomerServiceImpl(CustomerRepository customerRepository) {
			super();
			this.customerRepository = customerRepository;
			
		}

		@Override
		public Customer getCustomerById(long customerId) {
			
			return customerRepository.findById(customerId).orElseThrow(()->new CustomerNotFoundException("Customer","Id",customerId));
		}


		@Override
		public Customer saveCustomer(Customer customer) {
			
			return customerRepository.save(customer);
		}
		@Override
		public Customer loginCustomer(Customer customer) {
			
			return this.customerRepository.findByCustomerEmailIdAndCustomerPassword(customer.customerEmailId,customer.customerPassword).orElseThrow(()->new CustomerNotFoundException("Customer ", "Id",customer.customerEmailId+" and password "+customer.customerPassword ));
		}
		


		@Override
		public Customer updateCustomer(Customer customer,long customerId) {
		
		Customer existingCustomer=customerRepository.findById(customerId).orElseThrow(()->new CustomerNotFoundException("Customer","Id",customerId));	
		existingCustomer.setCustomerName(customer.getCustomerName());
		existingCustomer.setCustomerAddress(customer.getCustomerAddress());
		existingCustomer.setCustomerEmailId(customer.getCustomerEmailId());
		existingCustomer.setCustomerPassword(customer.getCustomerPassword());
		existingCustomer.setCustomerPhoneNo(customer.getCustomerPhoneNo());
		
		customerRepository.save(existingCustomer);
		return existingCustomer;
		}



		@Override
		public List<Customer> getAllCustomers() {
		
			return customerRepository.findAll();
		}



		@Override
		public void deleteCustomer(long customerId) {
			customerRepository.findById(customerId).orElseThrow(()->new CustomerNotFoundException("Customer","Id",customerId));
			customerRepository.deleteById(customerId);
			
		}

}