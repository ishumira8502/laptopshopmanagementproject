package com.laptopshop.serviceImpl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.laptopshop.exception.BillingNotFoundException;
import com.laptopshop.model.Billing;
import com.laptopshop.model.Customer;
import com.laptopshop.model.LaptopDetails;
import com.laptopshop.repository.BillingRepository;
import com.laptopshop.service.BillingService;
import com.laptopshop.service.CustomerService;
import com.laptopshop.service.LaptopDetailsService;


@Service
public  class BillingServiceImpl implements BillingService {
	
	
	
	@Autowired
    private BillingRepository billingRepository;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private LaptopDetailsService laptopdetailsService;
	
	


        public BillingServiceImpl(BillingRepository billingRepository, CustomerService customerService,
        		LaptopDetailsService laptopdetailsService) {
		super();
		this.billingRepository = billingRepository;
		this.customerService = customerService;
		this.laptopdetailsService = laptopdetailsService;
		

	}

    @Override
    public Billing addBilling(Billing billing,long customerId,long laptopModelId) {
		// TODO Auto-generated method stub
	LaptopDetails laptopDetails=laptopdetailsService.getLaptopDetailsById(laptopModelId);
	billing.setLaptopBrandName(laptopDetails.getLaptopBrandName());
	billing.setLaptopSpecification(laptopDetails.getLaptopSpecification());
	billing.setLaptopItemPrice(laptopDetails.getLaptopItemPrice());
	billing.setLaptopdetails(laptopDetails);
	
	Customer customer=customerService.getCustomerById(customerId);
	billing.setCustomerName(customer.getCustomerName());
	billing.setCustomerAddress(customer.getCustomerAddress());
	billing.setCustomerEmailId(customer.getCustomerEmailId());
	billing.setCustomerPhoneNo(customer.getCustomerPhoneNo());
	
	billing.setCustomer(customer);
	     return billingRepository.save(billing);
	}



	@Override
	public List<Billing> getAllBillings() {
		return billingRepository.findAll();
	}
	@Override
	public List<Billing> getAllBillingByLaptopModelId(long laptopModelId) {
		return billingRepository.findByLaptopdetailsLaptopModelId(laptopModelId);
	}


	@Override
	public Billing getBillingById(long billId) {
		
		return billingRepository.findById(billId).orElseThrow(()->new BillingNotFoundException("Billing","Id",billId));
	}


    @Override
	public void deleteBilling(long billId) {
		billingRepository.findById(billId).orElseThrow(()->new BillingNotFoundException("Billing","Id",billId));
		billingRepository.deleteById(billId);
		
	}

}