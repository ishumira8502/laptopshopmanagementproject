package com.laptopshop.service;


import java.util.List;

import com.laptopshop.model.LaptopDetails;

public interface LaptopDetailsService {
	LaptopDetails addLaptopDetails(LaptopDetails laptopDetails,long userId);
	List<LaptopDetails> getAllLaptopDetails();
	LaptopDetails getLaptopDetailsById(long laptopModelId);
	LaptopDetails updateLaptopDetails(LaptopDetails laptopDetails, long laptopModelId);
	void deleteLaptopDetails(long laptopModelId);

}