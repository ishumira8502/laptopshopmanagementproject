package com.laptopshop.service;


import com.laptopshop.model.Users;

public interface UsersService {
		Users saveUsers(Users users);
		Users loginUsers(Users users);
		
		Users getUserById( long userId);

}