package com.laptopshop.service;


import java.util.List;

import com.laptopshop.model.Customer;



public interface CustomerService {
	Customer saveCustomer(Customer customer);
	Customer loginCustomer(Customer customer);
	Customer updateCustomer(Customer customer,long customerId);
	Customer getCustomerById(long customerId);
	List<Customer> getAllCustomers();
	//Customer getCustomerByEmailId(Customer customer,String customerEmailId);
	void deleteCustomer(long customerId);

}